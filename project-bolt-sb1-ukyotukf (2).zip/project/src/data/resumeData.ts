// Resume data
export interface Education {
  id: number;
  degree: string;
  institution: string;
  location: string;
  startDate: string;
  endDate: string;
  description: string;
}

export interface Experience {
  id: number;
  title: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string | null; // null for "present"
  description: string;
  highlights: string[];
}

export interface Skill {
  category: string;
  items: string[];
}

export const education: Education[] = [
  {
    id: 1,
    degree: 'Bachelor of Science in Computer Science',
    institution: 'University of Technology',
    location: 'Boston, MA',
    startDate: '2022',
    endDate: '2026',
    description: 'Specializing in artificial intelligence and computational linguistics. Participating in the Honors Program with focus on interdisciplinary studies between technology and humanities.',
  },
  {
    id: 2,
    degree: 'Summer Research Program',
    institution: 'Institute for Advanced Digital Studies',
    location: 'San Francisco, CA',
    startDate: '2024',
    endDate: '2024',
    description: 'Selected for competitive research program exploring natural language processing for creative applications.',
  },
];

export const experience: Experience[] = [
  {
    id: 1,
    title: 'Research Assistant',
    company: 'Digital Humanities Lab',
    location: 'Boston, MA',
    startDate: '2024',
    endDate: null, // Present
    description: 'Developing tools for computational analysis of literary texts.',
    highlights: [
      'Created Python library for extracting semantic patterns from poetic texts',
      'Collaborated with literature professors to develop research methodologies',
      'Presented findings at university research symposium',
    ],
  },
  {
    id: 2,
    title: 'Frontend Developer Intern',
    company: 'CreativeTech Solutions',
    location: 'Remote',
    startDate: '2023',
    endDate: '2023',
    description: 'Worked on interactive web applications for creative clients in the arts sector.',
    highlights: [
      'Developed responsive interfaces using React and Tailwind CSS',
      'Implemented interactive data visualizations using D3.js',
      'Participated in agile development process with weekly sprints',
    ],
  },
  {
    id: 3,
    title: 'Student Mentor',
    company: 'Code for All Initiative',
    location: 'Boston, MA',
    startDate: '2022',
    endDate: '2023',
    description: 'Taught programming fundamentals to high school students from underrepresented backgrounds.',
    highlights: [
      'Created custom learning materials for Python and web development',
      'Mentored 15+ students, with 80% continuing to advanced courses',
      'Organized end-of-year showcase for student projects',
    ],
  },
];

export const skills: Skill[] = [
  {
    category: 'Programming',
    items: ['Python', 'JavaScript', 'TypeScript', 'HTML/CSS', 'SQL', 'C++'],
  },
  {
    category: 'Web Technologies',
    items: ['React', 'Node.js', 'Express', 'Tailwind CSS', 'Next.js'],
  },
  {
    category: 'Data & ML',
    items: ['PyTorch', 'TensorFlow', 'NLP', 'Data Visualization', 'Jupyter'],
  },
  {
    category: 'Tools & Other',
    items: ['Git', 'Docker', 'Linux', 'Figma', 'Technical Writing'],
  },
];

export const certifications = [
  {
    id: 1,
    title: 'Deep Learning Specialization',
    issuer: 'Coursera / DeepLearning.AI',
    date: '2023',
    url: 'https://www.coursera.org',
  },
  {
    id: 2,
    title: 'Full Stack Web Development',
    issuer: 'freeCodeCamp',
    date: '2022',
    url: 'https://www.freecodecamp.org',
  },
];

export const languages = [
  { language: 'English', proficiency: 'Native' },
  { language: 'Spanish', proficiency: 'Intermediate' },
  { language: 'French', proficiency: 'Basic' },
];