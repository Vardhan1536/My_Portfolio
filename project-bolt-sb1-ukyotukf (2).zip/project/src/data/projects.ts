// Project data
interface Project {
  id: number;
  title: string;
  description: string;
  tags: string[];
  imageUrl: string;
  githubUrl: string;
  demoUrl: string;
  featured?: boolean;
}

export const projects: Project[] = [
  {
    id: 1,
    title: 'Neural Text Generator',
    description: 'A machine learning project that generates poetry and prose using a fine-tuned transformer model. Trained on classic literature and modern writing.',
    tags: ['Python', 'ML', 'NLP', 'PyTorch'],
    imageUrl: 'https://images.pexels.com/photos/2653362/pexels-photo-2653362.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: 'https://github.com',
    demoUrl: 'https://demo.com',
    featured: true,
  },
  {
    id: 2,
    title: 'Thoughtful Journal App',
    description: 'A personal journal application that uses sentiment analysis to track mood patterns and provide reflective prompts.',
    tags: ['React', 'Node', 'NLP', 'MongoDB'],
    imageUrl: 'https://images.pexels.com/photos/3760529/pexels-photo-3760529.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: 'https://github.com',
    demoUrl: 'https://demo.com',
    featured: true,
  },
  {
    id: 3,
    title: 'Literary Analysis Dashboard',
    description: 'Visualizes patterns and insights from classic literature using NLP techniques and interactive data visualization.',
    tags: ['Python', 'D3.js', 'NLP', 'Flask'],
    imageUrl: 'https://images.pexels.com/photos/590493/pexels-photo-590493.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: 'https://github.com',
    demoUrl: 'https://demo.com',
  },
  {
    id: 4,
    title: 'Poetic Code Visualizer',
    description: 'Transforms source code into visual poetry through algorithmic layout and styling. A fusion of programming and artistic expression.',
    tags: ['JavaScript', 'P5.js', 'Algorithms', 'Art'],
    imageUrl: 'https://images.pexels.com/photos/177598/pexels-photo-177598.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: 'https://github.com',
    demoUrl: 'https://demo.com',
  },
  {
    id: 5,
    title: 'Semantic Search Engine',
    description: 'A specialized search engine for philosophical texts that understands conceptual relationships beyond keywords.',
    tags: ['Python', 'ML', 'Elasticsearch', 'React'],
    imageUrl: 'https://images.pexels.com/photos/2115217/pexels-photo-2115217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: 'https://github.com',
    demoUrl: 'https://demo.com',
  },
  {
    id: 6,
    title: 'Interactive Poetry Map',
    description: 'Geospatial visualization of poetry from around the world, allowing exploration by theme, era, and location.',
    tags: ['React', 'MapBox', 'D3.js', 'GraphQL'],
    imageUrl: 'https://images.pexels.com/photos/3769138/pexels-photo-3769138.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: 'https://github.com',
    demoUrl: 'https://demo.com',
  },
];